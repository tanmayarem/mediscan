"""
N8N Webhook Integration Module

This module provides webhook endpoints that can be called from N8N workflows.
N8N can orchestrate the various features and integrate with external APIs.

Endpoints:
- /api/interactions/check (POST) - Check medicine interactions
- /api/pill/identify (POST) - Identify pill from image
- /api/severity/analyze (POST) - Analyze side effect severity
- /api/chatbot/query (POST) - Chatbot query
- /api/translate (POST) - Translate text
"""

from flask import Blueprint, request, jsonify, current_app
import logging
from typing import Dict, List
import os

from .interaction_checker import check_medicine_interactions
from .pill_identifier import identify_pill_from_image
from .severity_analyzer import analyze_side_effect_severity
from .chatbot import get_chatbot_response
from .translator import translate_text

logger = logging.getLogger(__name__)

# Create Blueprint for API routes
api_bp = Blueprint('api', __name__, url_prefix='/api')

# Helper to get medicine database - will be passed from main app
_medicine_db_path = None

def init_api(app, medicine_db_path=None):
    """Initialize API with medicine database path."""
    global _medicine_db_path
    _medicine_db_path = medicine_db_path


@api_bp.route('/interactions/check', methods=['POST'])
def check_interactions():
    """
    Webhook endpoint for checking medicine interactions.
    
    Expected JSON:
    {
        "medicines": ["Medicine1", "Medicine2", ...]
    }
    
    Returns:
    {
        "status": "success",
        "warnings": [...],
        "checked_medicines": [...]
    }
    """
    try:
        data = request.get_json()
        if not data or "medicines" not in data:
            return jsonify({"error": "Missing 'medicines' in request"}), 400
        
        medicines = data["medicines"]
        if not isinstance(medicines, list) or len(medicines) < 2:
            return jsonify({"error": "Need at least 2 medicines"}), 400
        
        result = check_medicine_interactions(medicines)
        return jsonify(result), 200
        
    except Exception as e:
        logger.error(f"Error in interactions check: {e}")
        return jsonify({"error": str(e)}), 500


@api_bp.route('/pill/identify', methods=['POST'])
def identify_pill():
    """
    Webhook endpoint for pill identification.
    
    Expected: multipart/form-data with 'image' file
    Or JSON with 'image_url'
    
    Returns:
    {
        "matches": [
            {
                "medicine_name": "...",
                "confidence": 85.5,
                ...
            }
        ]
    }
    """
    try:
        # Check if image is uploaded directly
        if 'image' in request.files:
            file = request.files['image']
            if file.filename:
                # Save temporarily
                from werkzeug.utils import secure_filename
                import tempfile
                import os
                
                filename = secure_filename(file.filename)
                temp_path = os.path.join(tempfile.gettempdir(), filename)
                file.save(temp_path)
                
                # Get database medicines - import here to avoid circular imports
                try:
                    import sqlite3
                    from pathlib import Path
                    
                    # Try to get database path from app config or use default
                    db_path = _medicine_db_path or Path(__file__).parent.parent / "medicine.db"
                    
                    if db_path.exists():
                        conn = sqlite3.connect(db_path)
                        conn.row_factory = sqlite3.Row
                        cur = conn.cursor()
                        cur.execute("SELECT * FROM medicines LIMIT 100")
                        rows = cur.fetchall()
                        conn.close()
                        medicine_data = [dict(row) for row in rows]
                    else:
                        medicine_data = []
                except Exception as e:
                    logger.error(f"Error loading medicine database: {e}")
                    medicine_data = []
                
                matches = identify_pill_from_image(temp_path, medicine_data)
                
                # Clean up
                try:
                    os.remove(temp_path)
                except:
                    pass
                
                return jsonify({"matches": matches}), 200
        
        # Or check for image URL
        data = request.get_json()
        if data and "image_url" in data:
            # Download image and process
            import requests
            from PIL import Image
            import tempfile
            
            img_response = requests.get(data["image_url"], timeout=10)
            img_response.raise_for_status()
            
            temp_path = tempfile.NamedTemporaryFile(delete=False, suffix=".jpg").name
            with open(temp_path, 'wb') as f:
                f.write(img_response.content)
            
            matches = identify_pill_from_image(temp_path, [])
            
            try:
                os.remove(temp_path)
            except:
                pass
            
            return jsonify({"matches": matches}), 200
        
        return jsonify({"error": "No image provided"}), 400
        
    except Exception as e:
        logger.error(f"Error in pill identification: {e}")
        return jsonify({"error": str(e)}), 500


@api_bp.route('/severity/analyze', methods=['POST'])
def analyze_severity():
    """
    Webhook endpoint for analyzing side effect severity.
    
    Expected JSON:
    {
        "side_effects": "Nausea, Dizziness, Severe allergic reaction"
    }
    
    Returns:
    {
        "mild": [...],
        "moderate": [...],
        "severe": [...],
        "summary": {...}
    }
    """
    try:
        data = request.get_json()
        if not data or "side_effects" not in data:
            return jsonify({"error": "Missing 'side_effects' in request"}), 400
        
        side_effects_text = data["side_effects"]
        result = analyze_side_effect_severity(side_effects_text)
        return jsonify(result), 200
        
    except Exception as e:
        logger.error(f"Error in severity analysis: {e}")
        return jsonify({"error": str(e)}), 500


@api_bp.route('/chatbot/query', methods=['POST'])
def chatbot_query():
    """
    Webhook endpoint for chatbot queries.
    
    Expected JSON:
    {
        "message": "What are the side effects of Paracetamol?",
        "context": {...}  // optional
    }
    
    Returns:
    {
        "response": "...",
        "sources": [...],
        "confidence": 0.9
    }
    """
    try:
        data = request.get_json()
        if not data or "message" not in data:
            return jsonify({"error": "Missing 'message' in request"}), 400
        
        message = data["message"]
        context = data.get("context")
        api_key = data.get("api_key")  # Can pass API key in request or use env
        
        result = get_chatbot_response(message, context, api_key)
        return jsonify(result), 200
        
    except Exception as e:
        logger.error(f"Error in chatbot query: {e}")
        return jsonify({"error": str(e)}), 500


@api_bp.route('/translate', methods=['POST'])
def translate():
    """
    Webhook endpoint for translation.
    
    Expected JSON:
    {
        "text": "Hello",
        "target_lang": "hi",
        "source_lang": "en"
    }
    
    Returns:
    {
        "translated": "..."
    }
    """
    try:
        data = request.get_json()
        if not data or "text" not in data or "target_lang" not in data:
            return jsonify({"error": "Missing required fields"}), 400
        
        text = data["text"]
        target_lang = data["target_lang"]
        source_lang = data.get("source_lang", "en")
        api_key = data.get("api_key")
        
        translated = translate_text(text, target_lang, source_lang, api_key)
        return jsonify({"translated": translated}), 200
        
    except Exception as e:
        logger.error(f"Error in translation: {e}")
        return jsonify({"error": str(e)}), 500


@api_bp.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint for n8n."""
    return jsonify({
        "status": "healthy",
        "service": "MedScan API",
        "endpoints": [
            "/api/interactions/check",
            "/api/pill/identify",
            "/api/severity/analyze",
            "/api/chatbot/query",
            "/api/translate"
        ]
    }), 200

