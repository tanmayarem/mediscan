# N8N Integration Setup Guide

This guide will help you set up N8N workflows to integrate MedScan features with external services and create a proper web deployment without using localhost URLs.

## What is N8N?

N8N is a workflow automation tool (similar to Zapier but open-source and self-hostable). It allows you to:
- Connect different APIs and services
- Create automated workflows
- Expose your Flask app as webhooks
- Deploy your app publicly (using n8n cloud or self-hosted)

## Prerequisites

1. **N8N Account** (choose one):
   - Free tier at [n8n.io](https://n8n.io) (cloud-hosted)
   - Self-hosted n8n (Docker or npm)

2. **Domain/Public URL** (for webhooks):
   - Use n8n cloud's webhook URLs
   - Or deploy your Flask app to a service like:
     - Heroku
     - Railway
     - Render
     - DigitalOcean App Platform

## Step-by-Step Setup

### Step 1: Deploy Your Flask App

#### Option A: Deploy to Railway/Render/Heroku

1. **Prepare for deployment**:
   ```bash
   # Create Procfile
   echo "web: python app.py" > Procfile
   
   # Update requirements.txt (already done)
   ```

2. **Deploy to Railway** (Recommended - Free tier available):
   - Go to [railway.app](https://railway.app)
   - Create new project
   - Connect GitHub repo
   - Railway auto-detects Flask and deploys
   - Get your public URL: `https://yourapp.railway.app`

3. **Set Environment Variables**:
   - `FLASK_SECRET_KEY`: Generate a secure key
   - `OPENAI_API_KEY` (optional): For chatbot
   - `GOOGLE_TRANSLATE_API_KEY` (optional): For translations

#### Option B: Use n8n's Webhook Feature

If you can't deploy publicly, n8n can still work with:
- ngrok (tunnels localhost to public URL)
- LocalTunnel
- Cloudflare Tunnel

### Step 2: Set Up N8N Workflow

1. **Login to n8n**: [app.n8n.io](https://app.n8n.io)

2. **Create New Workflow** → Name it "MedScan Integration"

3. **Add Webhook Node**:
   - Click "+" → Search "Webhook"
   - Method: POST
   - Path: `medscan-interactions` (or any name)
   - Save workflow → **Copy the webhook URL** (looks like: `https://your-n8n.app.n8n.io/webhook/medscan-interactions`)  

### Step 3: Configure N8N Workflows for Each Feature

#### Workflow 1: Medicine Interaction Checker

```
[Webhook] → [HTTP Request] → [RxNav API] → [Transform Data] → [Respond to Webhook]
```

1. **Webhook Node**:
   - Method: POST
   - Path: `check-interactions`
   - Expected payload: `{ "medicines": ["Medicine1", "Medicine2"] }`

2. **HTTP Request Node**:
   - Method: GET
   - URL: `https://rxnav.nlm.nih.gov/REST/rxcui?name={{ $json.medicines[0] }}`
   - (Repeat for each medicine, or use Loop/Function nodes)

3. **Function Node** (JavaScript) - Call interaction API:
   ```javascript
   // Get RxCUIs for both medicines
   const rxcui1 = $input.first().json.rxnormId[0];
   const rxcui2 = $input.all()[1].json.rxnormId[0];
   
   return {
     json: {
       url: `https://rxnav.nlm.nih.gov/REST/interaction?rxcui=${rxcui1} ${rxcui2}`
     }
   };
   ```

4. **HTTP Request Node** - Check interactions:
   - Method: GET
   - URL: `{{ $json.url }}`

5. **Respond to Webhook Node**:
   - Return the interaction results

**Alternative**: Use your Flask API directly:
```
[Webhook] → [HTTP Request to Flask] → [Respond to Webhook]
```
- URL: `https://yourapp.railway.app/api/interactions/check`
- Method: POST
- Body: Same as webhook received

#### Workflow 2: Pill Identifier

```
[Webhook with File] → [HTTP Request to Flask] → [Respond to Webhook]
```

1. **Webhook Node**:
   - Method: POST
   - Path: `pill-identify`
   - Accept file uploads

2. **HTTP Request Node**:
   - Method: POST
   - URL: `https://yourapp.railway.app/api/pill/identify`
   - Body: Forward the image file
   - Headers: `Content-Type: multipart/form-data`

3. **Respond to Webhook**: Return matches

#### Workflow 3: Chatbot Integration

```
[Webhook] → [OpenAI API] → [Transform] → [Respond to Webhook]
```

1. **Webhook Node**:
   - Method: POST
   - Path: `chatbot`
   - Payload: `{ "message": "..." }`

2. **OpenAI Node** (if available) or HTTP Request:
   - Use OpenAI API directly
   - Or call Flask endpoint: `https://yourapp.railway.app/api/chatbot/query`

3. **Respond to Webhook**: Return response

### Step 4: Update Frontend to Use N8N Webhooks

In your Flask app templates, add JavaScript to call n8n webhooks:

```javascript
// Example: Check interactions via n8n
async function checkInteractionsViaN8N(medicines) {
  const response = await fetch('https://your-n8n.app.n8n.io/webhook/check-interactions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ medicines: medicines })
  });
  return await response.json();
}
```

### Step 5: Security (Important!)

1. **Add Authentication to Webhooks**:
   - In n8n Webhook settings, enable "Basic Auth" or "Header Auth"
   - Add authentication token in your frontend calls

2. **Rate Limiting**:
   - Configure n8n to limit requests per IP
   - Or use n8n's built-in rate limiting

3. **CORS** (if calling from browser):
   - Configure your Flask app to allow CORS from your domain
   - Install Flask-CORS: `pip install flask-cors`

## API Endpoints Available

Your Flask app exposes these endpoints (if deployed publicly):

1. **Interaction Checker**:
   - `POST /api/interactions/check`
   - Body: `{ "medicines": ["Med1", "Med2"] }`

2. **Pill Identifier**:
   - `POST /api/pill/identify`
   - Form-data with `image` file

3. **Severity Analyzer**:
   - `POST /api/severity/analyze`
   - Body: `{ "side_effects": "Nausea, Dizziness" }`

4. **Chatbot**:
   - `POST /api/chatbot/query`
   - Body: `{ "message": "...", "context": {...} }`

5. **Translation**:
   - `POST /api/translate`
   - Body: `{ "text": "...", "target_lang": "hi", "source_lang": "en" }`

6. **Health Check**:
   - `GET /api/health`

## Testing the Integration

1. **Test locally first**:
   ```bash
   # Start Flask app
   python app.py
   
   # Test endpoint
   curl -X POST http://localhost:5000/api/interactions/check \
     -H "Content-Type: application/json" \
     -d '{"medicines": ["Ibuprofen", "Aspirin"]}'
   ```

2. **Test n8n webhook**:
   - Use n8n's "Execute Workflow" button
   - Or use Postman/curl to hit the webhook URL

3. **Test from frontend**:
   - Open browser console
   - Call the JavaScript function
   - Check response

## Troubleshooting

1. **Webhook not receiving data**:
   - Check n8n workflow is active (green toggle)
   - Verify webhook URL is correct
   - Check payload format matches expected

2. **CORS errors**:
   - Install flask-cors: `pip install flask-cors`
   - Add to app.py: `from flask_cors import CORS; CORS(app)`

3. **API errors**:
   - Check Flask logs for errors
   - Verify environment variables are set
   - Test endpoints directly with curl

## Next Steps

1. **Add more workflows** for other features
2. **Set up scheduled tasks** (e.g., daily database updates)
3. **Add error handling** and retry logic in n8n
4. **Monitor workflows** using n8n's execution history

## Resources

- [N8N Documentation](https://docs.n8n.io)
- [N8N Community Forum](https://community.n8n.io)
- [Railway Deployment Guide](https://docs.railway.app)
- [Flask Deployment Guide](https://flask.palletsprojects.com/en/latest/deploying/)

